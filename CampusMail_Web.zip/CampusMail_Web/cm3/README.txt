CampusMail Web V5 — Entire UI Theme + Brand Upgrade

This version uses the supplied transparent CampusMail logo throughout the application.
The uploaded logo is already transparent and is used as-is; no background is added.

UI upgrades:
- CampusMail logo in the global navigation
- CampusMail logo on dashboard, loading screen, send/receive animations
- CM mail icon beside Email navigation
- Animated logo glow/float effects
- 3D glass cards and polished navigation
- Light / Dark / System theme across the entire application
- Theme-aware text, inputs, cards, tables, overlays and animations
- Existing attachment download fix retained
- Existing mail send/receive animations retained

Run on Windows:
.venv\\Scripts\\python.exe app.py
Then open http://127.0.0.1:5000
