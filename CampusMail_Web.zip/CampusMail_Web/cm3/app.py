import os, sqlite3, hashlib, secrets, smtplib, imaplib, email, mimetypes, csv, io, shutil, re
from email.message import EmailMessage
from email.header import decode_header, make_header
from email.utils import parseaddr
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, abort, jsonify
from werkzeug.utils import secure_filename
from cryptography.fernet import Fernet

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,'campusmail.db'); KEY_FILE=os.path.join(BASE,'secret.key')
UPLOAD=os.path.join(BASE,'uploads'); BACKUP=os.path.join(BASE,'backups')
os.makedirs(UPLOAD,exist_ok=True); os.makedirs(BACKUP,exist_ok=True)
app=Flask(__name__); app.secret_key=os.environ.get('CAMPUSMAIL_SECRET') or secrets.token_hex(32)


def get_fernet():
    if not os.path.exists(KEY_FILE): open(KEY_FILE,'wb').write(Fernet.generate_key())
    return Fernet(open(KEY_FILE,'rb').read())
F=get_fernet()

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def hashpw(p):
    salt=secrets.token_bytes(16); h=hashlib.pbkdf2_hmac('sha256',p.encode(),salt,180000)
    return f'pbkdf2${salt.hex()}${h.hex()}'

def checkpw(p,s):
    try:
        scheme,salt,h=s.split('$'); x=hashlib.pbkdf2_hmac('sha256',p.encode(),bytes.fromhex(salt),180000).hex()
        return scheme=='pbkdf2' and secrets.compare_digest(x,h)
    except Exception:return False

def init():
    c=db(); c.executescript('''
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,password_hash TEXT NOT NULL,name TEXT,role TEXT,department TEXT,email TEXT,imap_server TEXT,imap_port INTEGER DEFAULT 993,smtp_server TEXT,smtp_port INTEGER DEFAULT 587,email_secret TEXT);
    CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY,name TEXT,code TEXT UNIQUE,hod_username TEXT);
    CREATE TABLE IF NOT EXISTS announcements(id INTEGER PRIMARY KEY,title TEXT,body TEXT,department TEXT,created_by TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS requests(id INTEGER PRIMARY KEY,username TEXT,type TEXT,title TEXT,department TEXT,start_date TEXT,end_date TEXT,description TEXT,status TEXT DEFAULT 'Pending Faculty',faculty_approved_by TEXT,hod_approved_by TEXT,rejection_reason TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,username TEXT,title TEXT,body TEXT,is_read INTEGER DEFAULT 0,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY,actor TEXT,action TEXT,target TEXT,details TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    ''')
    if c.execute('select count(*) from users').fetchone()[0]==0:
        for u in [('student','student123','Student User','Student','CSE'),('faculty','faculty123','Faculty User','Faculty','CSE'),('hod','hod123','HOD User','HOD','CSE'),('admin','admin123','System Admin','Admin','ADMIN')]:
            c.execute('insert into users(username,password_hash,name,role,department) values(?,?,?,?,?)',(u[0],hashpw(u[1]),u[2],u[3],u[4]))
        for d in [('Computer Science and Engineering','CSE','hod'),('Electronics and Communication','ECE',''),('Mechanical Engineering','MECH',''),('Electrical and Electronics','EEE',''),('Administration','ADMIN','admin')]:c.execute('insert into departments(name,code,hod_username) values(?,?,?)',d)
        c.execute('insert into announcements(title,body,department,created_by) values(?,?,?,?)',('Welcome to CampusMail','Welcome to the college communication portal.','ALL','admin')); c.commit()
    c.close()
init()

def current():
    if 'uid' not in session:return None
    c=db();u=c.execute('select * from users where id=?',(session['uid'],)).fetchone();c.close();return u

def login_required(f):
    @wraps(f)
    def w(*a,**k):
        if not current():return redirect(url_for('login'))
        return f(*a,**k)
    return w

def role_required(*roles):
    def deco(f):
        @wraps(f)
        def w(*a,**k):
            u=current()
            if not u:return redirect(url_for('login'))
            if u['role'] not in roles:flash('Access denied.','danger');return redirect(url_for('dashboard'))
            return f(*a,**k)
        return w
    return deco

def audit(actor,action,target='',details=''):
    c=db();c.execute('insert into audit_log(actor,action,target,details) values(?,?,?,?)',(actor,action,target,details));c.commit();c.close()

def notify(user,title,body):
    c=db();c.execute('insert into notifications(username,title,body) values(?,?,?)',(user,title,body));c.commit();c.close()

def enc(v):return F.encrypt(v.encode()).decode()
def dec(v):
    try:return F.decrypt(v.encode()).decode()
    except:return ''

def mail_config(u):
    if not u['email'] or not u['email_secret']:raise ValueError('Email account is not configured for this user. Open Email Account.')
    return u['email'],dec(u['email_secret'])

def imap_conn(u):
    addr,pw=mail_config(u);m=imaplib.IMAP4_SSL(u['imap_server'],int(u['imap_port'] or 993),timeout=30);m.login(addr,pw);return m

def decode(v):
    try:return str(make_header(decode_header(v or '')))
    except:return v or ''

def folders(m):
    typ,data=m.list();names=[]
    for x in data or []:
        s=x.decode(errors='ignore')
        q=re.findall(r'"([^"]+)"\s*$',s)
        if q:names.append(q[-1])
    return names

def find_folder(m,want):
    names=folders(m)
    if want in names:return want
    low=want.lower()
    for n in names:
        if n.lower().endswith(low) or low in n.lower():return n
    return want

def inbox_headers(u,folder='INBOX',limit=30,search=''):
    m=imap_conn(u);real=find_folder(m,folder);m.select(real,readonly=True)
    criteria='ALL'
    if search.strip():
        q=search.strip().replace('"','')
        criteria=f'(OR SUBJECT "{q}" FROM "{q}")'
    typ,data=m.uid('search',None,criteria);ids=(data[0].split() if data and data[0] else [])[-limit:][::-1];out=[]
    if ids:
        typ,data=m.uid('fetch',b','.join(ids),b'(BODY.PEEK[HEADER.FIELDS (FROM TO SUBJECT DATE)] FLAGS UID)')
        for item in data:
            if not isinstance(item,tuple):continue
            raw=item[1];msg=email.message_from_bytes(raw);meta=item[0].decode(errors='ignore') if item[0] else ''
            z=re.search(r'UID (\d+)',meta);uid=z.group(1) if z else ''
            out.append({'uid':uid,'from':decode(msg.get('From')),'to':decode(msg.get('To')),'subject':decode(msg.get('Subject')),'date':decode(msg.get('Date')),'unread':'\\Seen' not in meta,'starred':'\\Flagged' in meta,'folder':real})
    m.logout();return out,real

def fetch_message(u,uid,folder='INBOX'):
    m=imap_conn(u);real=find_folder(m,folder);m.select(real,readonly=True);typ,data=m.uid('fetch',str(uid),'(RFC822)');raw=next((x[1] for x in data if isinstance(x,tuple)),b'');m.logout()
    if not raw:raise ValueError('Message not found.')
    return email.message_from_bytes(raw),real

def fetch_attachment(u,uid,folder,part_index):
    """Fetch one MIME attachment from the user's mailbox by MIME part index.

    The message is fetched from IMAP again instead of trusting a client-supplied
    filesystem path. This keeps attachments on the mail server and prevents a
    user from downloading arbitrary local files.
    """
    try:
        idx=int(part_index)
    except (TypeError, ValueError):
        raise ValueError('Invalid attachment.')
    if idx < 0:
        raise ValueError('Invalid attachment.')

    m,real=fetch_message(u,uid,folder)
    # Keep the same MIME-part index used by email_view().
    # m.walk() includes non-attachment MIME parts, so filtering the list first
    # would make the index point at the wrong part for many real emails.
    part=None
    for i,p in enumerate(m.walk() if m.is_multipart() else []):
        if i == idx and p.get_filename():
            part=p
            break
    if part is None:
        raise ValueError('Attachment not found.')

    data=part.get_payload(decode=True)
    if data is None:
        data=b''
    filename=decode(part.get_filename()) or 'attachment'
    filename=secure_filename(filename) or 'attachment'
    mimetype=part.get_content_type() or 'application/octet-stream'
    return data,filename,mimetype,real

def set_flag(u,uid,folder,flag,enabled=True):
    m=imap_conn(u);real=find_folder(m,folder);m.select(real)
    m.uid('store',str(uid),'+FLAGS' if enabled else '-FLAGS',f'({flag})');m.logout()

def delete_message(u,uid,folder):
    m=imap_conn(u);real=find_folder(m,folder);m.select(real);m.uid('store',str(uid),'+FLAGS','(\\Deleted)');m.expunge();m.logout()

def send_mail(u,to,subject,body,files):
    addr,pw=mail_config(u);msg=EmailMessage();msg['From']=addr;msg['To']=to;msg['Subject']=subject;msg.set_content(body)
    for path in files:
        with open(path,'rb') as f:data=f.read()
        ctype=mimetypes.guess_type(path)[0] or 'application/octet-stream';main,sub=ctype.split('/',1);msg.add_attachment(data,maintype=main,subtype=sub,filename=os.path.basename(path))
    s=smtplib.SMTP(u['smtp_server'],int(u['smtp_port'] or 587),timeout=30);s.ehlo();s.starttls();s.ehlo();s.login(addr,pw);s.send_message(msg);s.quit()

def message_body(m):
    if m.is_multipart():
        for p in m.walk():
            if p.get_content_type()=='text/plain' and not p.get_filename():
                data=p.get_payload(decode=True);return data.decode(p.get_content_charset() or 'utf-8',errors='replace') if data else ''
        return ''
    data=m.get_payload(decode=True);return data.decode(m.get_content_charset() or 'utf-8',errors='replace') if data else str(m.get_payload())

@app.context_processor
def common():
    u=current();n=0
    if u:
        c=db();n=c.execute('select count(*) from notifications where username=? and is_read=0',(u['username'],)).fetchone()[0];c.close()
    return {'me':u,'unread_notifications':n,'version':'V5 Final'}

@app.route('/')
def index():return redirect(url_for('dashboard') if current() else url_for('login'))
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        c=db();u=c.execute('select * from users where username=?',(request.form.get('username','').strip(),)).fetchone();c.close()
        if u and checkpw(request.form.get('password',''),u['password_hash']):session['uid']=u['id'];audit(u['username'],'LOGIN');return redirect(url_for('dashboard'))
        flash('Invalid username or password.','danger')
    return render_template('login.html')
@app.route('/logout')
@login_required
def logout():
    u=current();audit(u['username'],'LOGOUT');session.clear();return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    u=current();c=db();ann=c.execute('select * from announcements where department in (?,?) order by id desc limit 10',(u['department'],'ALL')).fetchall()
    if u['role']=='Student':req=c.execute('select * from requests where username=? order by id desc limit 10',(u['username'],)).fetchall()
    elif u['role']=='Faculty':req=c.execute("select * from requests where department=? and status='Pending Faculty' order by id desc",(u['department'],)).fetchall()
    elif u['role']=='HOD':req=c.execute("select * from requests where department=? and status='Pending HOD' order by id desc",(u['department'],)).fetchall()
    else:req=c.execute('select * from requests order by id desc limit 20').fetchall()
    c.close();return render_template('dashboard.html',ann=ann,requests=req)

@app.route('/email/check-new')
@login_required
def email_check_new():
    """Lightweight inbox poll used by the UI to detect newly arrived mail."""
    u=current(); folder=request.args.get('folder','INBOX')
    if folder.upper() != 'INBOX':
        return jsonify({'ok':True,'new':False,'uid':'','subject':'','from':''})
    try:
        msgs,real=inbox_headers(u,'INBOX',1,'')
        latest=msgs[0] if msgs else {}
        return jsonify({'ok':True,'new':False,'uid':latest.get('uid',''),'subject':latest.get('subject',''),'from':latest.get('from',''),'folder':real})
    except Exception as e:
        return jsonify({'ok':False,'error':str(e)}),200

@app.route('/email')
@login_required
def email_page():
    u=current();folder=request.args.get('folder','INBOX');q=request.args.get('q','')
    try:msgs,real=inbox_headers(u,folder,40,q)
    except Exception as e:msgs=[];real=folder;flash(f'Mail error: {e}','danger')
    return render_template('email.html',messages=msgs,folder=folder,real_folder=real,q=q)

@app.route('/email/view/<uid>')
@login_required
def email_view(uid):
    u=current();folder=request.args.get('folder','INBOX')
    try:m,real=fetch_message(u,uid,folder);body=message_body(m)
    except Exception as e:flash(f'Mail error: {e}','danger');return redirect(url_for('email_page',folder=folder))
    attachments=[]
    for i,p in enumerate(m.walk() if m.is_multipart() else []):
        if p.get_filename():attachments.append({'i':i,'name':decode(p.get_filename())})
    return render_template('message.html',m=m,body=body,folder=real,uid=uid,attachments=attachments)

@app.route('/email/attachment/<uid>/<int:part_index>')
@login_required
def email_attachment(uid,part_index):
    u=current()
    folder=request.args.get('folder','INBOX')
    try:
        data,filename,mimetype,real=fetch_attachment(u,uid,folder,part_index)
        audit(u['username'],'EMAIL_ATTACHMENT_DOWNLOADED',filename,f'{real}:{uid}:{part_index}')
        return send_file(io.BytesIO(data),as_attachment=True,download_name=filename,mimetype=mimetype)
    except Exception as e:
        flash(f'Attachment download failed: {e}','danger')
        return redirect(url_for('email_view',uid=uid,folder=folder))

@app.route('/email/flag/<uid>',methods=['POST'])
@login_required
def email_flag(uid):
    u=current();folder=request.form.get('folder','INBOX');flag=request.form.get('flag');enabled=request.form.get('enabled')=='1'
    try:set_flag(u,uid,folder,'\\Flagged' if flag=='star' else '\\Seen',enabled);flash('Message updated.','success')
    except Exception as e:flash(f'Mail error: {e}','danger')
    return redirect(request.referrer or url_for('email_page',folder=folder))

@app.route('/email/delete/<uid>',methods=['POST'])
@login_required
def email_delete(uid):
    u=current();folder=request.form.get('folder','INBOX')
    try:delete_message(u,uid,folder);audit(u['username'],'EMAIL_DELETED',uid,folder);flash('Message deleted.','success')
    except Exception as e:flash(f'Mail error: {e}','danger')
    return redirect(url_for('email_page',folder=folder))

@app.route('/compose',methods=['GET','POST'])
@login_required
def compose():
    u=current()
    if request.method=='POST':
        paths=[]
        for f in request.files.getlist('attachments'):
            if f and f.filename:
                p=os.path.join(UPLOAD,secrets.token_hex(8)+'_'+secure_filename(f.filename));f.save(p);paths.append(p)
        try:send_mail(u,request.form['to'],request.form.get('subject',''),request.form.get('body',''),paths);audit(u['username'],'EMAIL_SENT',request.form['to'],request.form.get('subject',''));flash('Email sent successfully.','success')
        except Exception as e:flash(f'Email error: {e}','danger')
        finally:
            for p in paths:
                try:os.remove(p)
                except:pass
        return redirect(url_for('email_page'))
    return render_template('compose.html',to=request.args.get('to',''),subject=request.args.get('subject',''),body=request.args.get('body',''))

@app.route('/account',methods=['GET','POST'])
@login_required
def account():
    u=current()
    if request.method=='POST':
        try:
            emailaddr=request.form['email'].strip();secret=request.form['email_password']
            if '@' not in emailaddr:raise ValueError('Enter a valid email address.')
            c=db();c.execute('update users set email=?,imap_server=?,imap_port=?,smtp_server=?,smtp_port=?,email_secret=? where id=?',(emailaddr,request.form['imap_server'].strip(),int(request.form['imap_port']),request.form['smtp_server'].strip(),int(request.form['smtp_port']),enc(secret),u['id']));c.commit();c.close();audit(u['username'],'EMAIL_CONFIGURED',emailaddr);flash('Real email account saved securely.','success')
        except Exception as e:flash(f'Could not save email settings: {e}','danger')
        return redirect(url_for('account'))
    return render_template('account.html')

@app.route('/request/new',methods=['GET','POST'])
@login_required
def new_request():
    u=current()
    if u['role']!='Student':flash('Only students create campus requests.','danger');return redirect(url_for('dashboard'))
    if request.method=='POST':
        c=db();c.execute('insert into requests(username,type,title,department,start_date,end_date,description) values(?,?,?,?,?,?,?)',(u['username'],request.form['type'],request.form['title'],u['department'],request.form['start_date'],request.form['end_date'],request.form['description']));rid=c.execute('select last_insert_rowid()').fetchone()[0]
        fac=c.execute("select username from users where role='Faculty' and department=? limit 1",(u['department'],)).fetchone()
        if fac:c.execute('insert into notifications(username,title,body) values(?,?,?)',(fac['username'],'New campus request',f'Request #{rid} from {u["username"]} requires Faculty approval.'))
        c.commit();c.close();audit(u['username'],'REQUEST_CREATED',str(rid),request.form['type']);flash('Request submitted.','success');return redirect(url_for('dashboard'))
    return render_template('new_request.html')

@app.route('/request/<int:rid>/action',methods=['POST'])
@login_required
def request_action(rid):
    u=current();action=request.form['action'];reason=request.form.get('reason','').strip();c=db();r=c.execute('select * from requests where id=?',(rid,)).fetchone()
    if not r:c.close();flash('Request not found.','danger');return redirect(url_for('dashboard'))
    if action=='reject' and not reason:c.close();flash('A rejection reason is required.','danger');return redirect(url_for('dashboard'))
    if u['role']=='Faculty' and r['department']==u['department'] and r['status']=='Pending Faculty':
        if action=='approve':c.execute("update requests set status='Pending HOD',faculty_approved_by=? where id=?",(u['username'],rid))
        else:c.execute("update requests set status='Rejected',rejection_reason=?,faculty_approved_by=? where id=?",(reason,u['username'],rid))
        hod=c.execute("select username from users where role='HOD' and department=? limit 1",(r['department'],)).fetchone()
        if action=='approve' and hod:c.execute('insert into notifications(username,title,body) values(?,?,?)',(hod['username'],'Request awaiting HOD approval',f'Request #{rid} requires your approval.'))
        c.execute('insert into notifications(username,title,body) values(?,?,?)',(r['username'],'Request updated',f'Request #{rid} is now {"Pending HOD" if action=="approve" else "Rejected"}. {reason}'))
    elif u['role']=='HOD' and r['department']==u['department'] and r['status']=='Pending HOD':
        st='Approved' if action=='approve' else 'Rejected';c.execute('update requests set status=?,hod_approved_by=?,rejection_reason=? where id=?',(st,u['username'],'' if action=='approve' else reason,rid));c.execute('insert into notifications(username,title,body) values(?,?,?)',(r['username'],'Request completed',f'Request #{rid} is {st}. {reason}'))
    else:c.close();flash('You cannot process this request.','danger');return redirect(url_for('dashboard'))
    c.commit();c.close();audit(u['username'],'REQUEST_'+action.upper(),str(rid),reason);flash('Request updated.','success');return redirect(url_for('dashboard'))

@app.route('/notifications')
@login_required
def notifications():
    c=db();rows=c.execute('select * from notifications where username=? order by id desc',(current()['username'],)).fetchall();c.close();return render_template('notifications.html',rows=rows)
@app.route('/notifications/read',methods=['POST'])
@login_required
def notifications_read():
    c=db();c.execute('update notifications set is_read=1 where username=?',(current()['username'],));c.commit();c.close();return redirect(url_for('notifications'))

@app.route('/admin')
@role_required('Admin')
def admin():
    c=db();users=c.execute('select id,username,name,role,department,email,imap_server,smtp_server from users order by id').fetchall();logs=c.execute('select * from audit_log order by id desc limit 150').fetchall();deps=c.execute('select * from departments order by name').fetchall();c.close();return render_template('admin.html',users=users,logs=logs,deps=deps)

@app.route('/admin/user',methods=['POST'])
@role_required('Admin')
def admin_user():
    uid=request.form.get('id');c=db();emailaddr=request.form.get('email','').strip();pw=request.form.get('password','');username=request.form.get('username','').strip()
    try:
        if uid:
            if int(uid)==current()['id'] and request.form['role']!='Admin':raise ValueError('You cannot remove your own Admin role.')
            if pw:c.execute('update users set name=?,role=?,department=?,email=?,password_hash=? where id=?',(request.form['name'],request.form['role'],request.form['department'],emailaddr,hashpw(pw),uid))
            else:c.execute('update users set name=?,role=?,department=?,email=? where id=?',(request.form['name'],request.form['role'],request.form['department'],emailaddr,uid))
            action='USER_UPDATED';target=username or uid
        else:
            if not pw:raise ValueError('Password required for a new user.')
            c.execute('insert into users(username,password_hash,name,role,department,email) values(?,?,?,?,?,?)',(username,hashpw(pw),request.form['name'],request.form['role'],request.form['department'],emailaddr));action='USER_CREATED';target=username
        c.commit();flash('User saved.','success')
    except sqlite3.IntegrityError:flash('Username already exists.','danger')
    except Exception as e:flash(str(e),'danger')
    finally:c.close()
    audit(current()['username'],action if 'action' in locals() else 'USER_SAVE_FAILED',target if 'target' in locals() else username);return redirect(url_for('admin'))

@app.route('/admin/user/delete/<int:uid>',methods=['POST'])
@role_required('Admin')
def admin_delete(uid):
    if uid==current()['id']:flash('You cannot delete your own account.','danger');return redirect(url_for('admin'))
    c=db();u=c.execute('select * from users where id=?',(uid,)).fetchone()
    if u and u['role']=='Admin' and c.execute("select count(*) from users where role='Admin'").fetchone()[0]<=1:flash('Cannot delete the last Admin.','danger');c.close();return redirect(url_for('admin'))
    c.execute('delete from users where id=?',(uid,));c.commit();c.close();audit(current()['username'],'USER_DELETED',str(uid));flash('User deleted.','success');return redirect(url_for('admin'))

@app.route('/admin/backup')
@role_required('Admin')
def backup_db():
    name='campusmail_backup_'+__import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')+'.db';path=os.path.join(BACKUP,name);shutil.copy2(DB,path);audit(current()['username'],'DB_BACKUP',name);return send_file(path,as_attachment=True,download_name=name)

@app.route('/admin/audit.csv')
@role_required('Admin')
def audit_csv():
    c=db();rows=c.execute('select created_at,actor,action,target,details from audit_log order by id desc').fetchall();c.close();s=io.StringIO();w=csv.writer(s);w.writerow(['Created At','Actor','Action','Target','Details']);w.writerows([tuple(r) for r in rows]);bio=io.BytesIO(s.getvalue().encode('utf-8-sig'));audit(current()['username'],'AUDIT_EXPORT','audit.csv');return send_file(bio,as_attachment=True,download_name='campusmail_audit.csv',mimetype='text/csv')

@app.route('/admin/restore',methods=['POST'])
@role_required('Admin')
def restore_db():
    f=request.files.get('backup')
    if not f or not f.filename.endswith('.db'):flash('Select a SQLite .db backup.','danger');return redirect(url_for('admin'))
    temp=os.path.join(BACKUP,'restore_'+secrets.token_hex(6)+'.db');f.save(temp)
    try:
        test=sqlite3.connect(temp);ok=test.execute("select name from sqlite_master where type='table' and name='users'").fetchone();test.close()
        if not ok:raise ValueError('Invalid CampusMail database backup.')
        safety=os.path.join(BACKUP,'before_restore_'+__import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')+'.db');shutil.copy2(DB,safety);shutil.copy2(temp,DB);audit(current()['username'],'DB_RESTORE',f.filename)
        flash('Database restored. Please log in again.','success');session.clear();return redirect(url_for('login'))
    except Exception as e:flash(f'Restore failed: {e}','danger');return redirect(url_for('admin'))
    finally:
        try:os.remove(temp)
        except:pass

@app.route('/announce',methods=['POST'])
@role_required('Faculty','HOD','Admin')
def announce():
    u=current();c=db();dept=request.form.get('department','ALL')
    if u['role']!='Admin':dept=u['department']
    c.execute('insert into announcements(title,body,department,created_by) values(?,?,?,?)',(request.form['title'],request.form['body'],dept,u['username']));c.commit();c.close();flash('Announcement published.','success');return redirect(url_for('dashboard'))

@app.route('/change-password',methods=['GET','POST'])
@login_required
def change_password():
    if request.method=='POST':
        u=current()
        if not checkpw(request.form['current'],u['password_hash']):flash('Current password is incorrect.','danger')
        elif len(request.form['new'])<8:flash('New password must be at least 8 characters.','danger')
        elif request.form['new']!=request.form['confirm']:flash('Passwords do not match.','danger')
        else:
            c=db();c.execute('update users set password_hash=? where id=?',(hashpw(request.form['new']),u['id']));c.commit();c.close();audit(u['username'],'PASSWORD_CHANGED',u['username']);flash('Password changed.','success');return redirect(url_for('dashboard'))
    return render_template('change_password.html')

@app.route('/about')
def about():return render_template('about.html')

if __name__=='__main__':app.run(host='127.0.0.1',port=int(os.environ.get('PORT',5000)),debug=False)
